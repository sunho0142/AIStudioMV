# APK build instructions (mobile-friendly)

1. Upload the **contents** of the AIStudioMV folder to the root of your GitHub repository, preserving `.github/workflows/build-apk.yml`.
2. Open your repository on GitHub, choose **Actions** > **Build Android APK** > **Run workflow** (or push a commit to `main`).
3. Wait for the workflow to finish with a green checkmark.
4. Open the successful run, then under **Artifacts** download **AIStudioMV-debug-apk**.
5. Extract the downloaded ZIP and install `app-debug.apk` on your Android phone.

This is a debug APK for personal testing. The original app provides local photo-to-MP4 creation; AI photo/video buttons are placeholders until a separate AI backend is connected. The current audio muxer only supports AAC audio, not MP3.

If the workflow fails, open the failing step and share the **last 20 log lines** rather than the full log.
