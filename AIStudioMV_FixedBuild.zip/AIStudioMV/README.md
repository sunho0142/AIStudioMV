# AI Studio MV — Android beginner starter

## What works
- Select multiple images with Android's document picker.
- Encode an H.264 1280×720, 24fps MP4 slideshow (3 seconds per image) using Android MediaCodec.
- Optionally mux AAC audio from an M4A/AAC file; the audio is truncated to the slideshow duration.
- Save to the device's `Movies/AIStudioMV` folder using MediaStore.
- Korean dark-themed basic interface.

## Not implemented yet
- AI image generation and AI video generation: the buttons explain that a backend API must be connected. No pretend AI generation is performed.
- MP3 direct mux/transcoding. Convert MP3 to AAC/M4A before selecting music.
- Timeline editor, animated transitions, lyric synchronization, and video clip stitching.

## Build
1. Install Android Studio with Android SDK Platform 35 and JDK 17.
2. Unzip this folder and open the `AIStudioMV` directory in Android Studio.
3. Let Android Studio sync Gradle (requires internet access). It may offer to install Gradle because this source ZIP does not contain the Gradle wrapper binary.
4. Select an Android 10+ device and press Run ▶.
5. Select images; optionally select an AAC-encoded `.m4a` song; tap `MP4 뮤직비디오 만들기`.
6. Check your Gallery under `Movies/AIStudioMV`.

## Important limitations
- Source code is provided; this environment cannot run Android Studio or compile an APK, so the build is **not verified**.
- Native Surface/Canvas encoding support varies by device. Test on a real phone.
- Long slideshows may consume memory and take time; this prototype has no background foreground service.
- Video length is fixed to 3 seconds per selected image, not automatically the entire song.
- The audio must be AAC in a compatible container. MP3 direct import is not supported in this starter.
- Never store third-party AI API secrets inside the app. Put keys on an authenticated backend and add usage quotas and safety checks before release.
