# 휴대폰만으로 APK 만들기

이 프로젝트는 Android Studio가 없는 환경에서 GitHub Actions의 Ubuntu 빌드 머신을 사용하도록 구성했습니다.

## 권장 경로: GitHub Codespaces + Actions
1. 휴대폰 크롬에서 github.com 가입 및 로그인.
2. 새 빈 저장소를 만듭니다 (예: AIStudioMV). API 키나 개인정보가 들어가지 않도록 주의하세요.
3. 저장소의 Code > Codespaces > Create codespace on main을 선택합니다. 모바일 브라우저에서 데스크톱 사이트 모드가 필요할 수 있습니다. Codespaces 사용 가능 여부 및 무료 할당량은 계정별로 다릅니다.
4. Codespaces의 파일 탐색기에 AIStudioMV_MobileBuild.zip을 업로드합니다. 업로드가 어려우면 브라우저의 데스크톱 사이트 모드 또는 파일 업로드 메뉴를 이용하세요.
5. Codespaces 터미널에서 아래 명령을 실행합니다 (업로드한 ZIP이 작업 디렉터리에 있을 때):

   unzip -o AIStudioMV_MobileBuild.zip -d /tmp/aistudiomv
   cp -r /tmp/aistudiomv/AIStudioMV/. .
   git add .
   git commit -m "Add Android project and APK workflow"
   git push

6. GitHub 저장소 > Actions > Build Android APK > Run workflow를 누릅니다. push로 자동 실행되었다면 그 실행을 확인하세요.
7. 성공한 실행의 Artifacts > AIStudioMV-debug-apk를 내려받고 ZIP을 압축 해제해 app-debug.apk를 찾습니다.
8. 휴대폰에서 APK 파일을 열어 설치합니다. Android의 '이 출처의 앱 설치 허용' 안내가 나올 수 있습니다. 본인이 직접 빌드한 APK인지 확인하고 진행하세요.

## 알아둘 점
- 이 APK는 테스트용 debug 서명입니다. Play Store 배포용이 아닙니다.
- AI 사진/영상 생성 버튼은 아직 안내용입니다. 외부 API 및 안전한 서버 연동이 필요합니다.
- 뮤직비디오 제작은 Android 기기별 MediaCodec/MediaMuxer 호환성 문제가 있을 수 있으며 실기기 테스트 전까지 성공을 보장할 수 없습니다.
- 음악 합성은 AAC/M4A만 지원하며 MP3는 현재 직접 합성하지 못합니다.
- GitHub Actions 또는 Codespaces 이용에는 계정별 제한/요금이 적용될 수 있습니다.
- GitHub 계정/토큰/API 키를 다른 사람에게 보내지 마세요.
